export interface Message {
  message: string;
  status: boolean;
}